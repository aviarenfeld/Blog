require 'test_helper'

class InstallTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
