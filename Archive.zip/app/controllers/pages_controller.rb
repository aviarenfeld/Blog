class PagesController < ApplicationController
    def about
	end
	def portfolio
	end
	def resume
	end
end



